class Product {
  final String id;
  final String title;
  final String description;
  final double price;
  final String imagePath;
  final String category; // صنف المنتج

  Product({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.imagePath,
    this.category = 'بهارات', // القيمة الافتراضية
  });
}

// قائمة الأصناف المتاحة
const List<String> productCategories = [
  'بهارات',
  'مجمدات',
  'بوضه',
  'سكاكر',
  'منضفات',
  'بقوليات',
  'موالح',
];
