import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/product.dart';

class Products with ChangeNotifier {
  List<Product> _items = [];

  List<Product> get items {
    return [..._items];
  }

  // إرجاع المنتجات المفلترة حسب الصنف
  List<Product> getByCategory(String category) {
    return _items.where((prod) => prod.category == category).toList();
  }

  Product findById(String id) {
    return _items.firstWhere((prod) => prod.id == id);
  }

  static const String _storageKey = 'user_products';

  Future<void> _saveToLocalStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final List<Map<String, dynamic>> data = _items.map((prod) => {
        'id': prod.id,
        'title': prod.title,
        'description': prod.description,
        'price': prod.price,
        'imagePath': prod.imagePath,
        'category': prod.category,
      }).toList();
      
      await prefs.setString(_storageKey, json.encode(data));
    } catch (error) {
      print('Error saving to local storage: $error');
    }
  }

  Future<void> fetchAndSetProducts() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (!prefs.containsKey(_storageKey)) {
        return;
      }
      
      final String? storedData = prefs.getString(_storageKey);
      if (storedData == null) return;

      final extractedData = json.decode(storedData) as List<dynamic>;
      final List<Product> loadedProducts = [];
      
      for (var prodData in extractedData) {
        loadedProducts.add(Product(
          id: prodData['id'],
          title: prodData['title'],
          description: prodData['description'],
          price: prodData['price'].toDouble(),
          imagePath: prodData['imagePath'],
          category: prodData['category'] ?? 'بهارات',
        ));
      }
      
      _items = loadedProducts;
      notifyListeners();
    } catch (error) {
      print('Error loading from local storage: $error');
    }
  }

  Future<void> addProduct(Product product) async {
    final newProduct = Product(
      id: DateTime.now().toString(),
      title: product.title,
      description: product.description,
      price: product.price,
      imagePath: product.imagePath,
      category: product.category,
    );
    _items.add(newProduct);
    notifyListeners();
    await _saveToLocalStorage();
  }

  Future<void> updateProduct(String id, Product newProduct) async {
    final prodIndex = _items.indexWhere((prod) => prod.id == id);
    if (prodIndex >= 0) {
      _items[prodIndex] = newProduct;
      notifyListeners();
      await _saveToLocalStorage();
    }
  }

  Future<void> deleteProduct(String id) async {
    _items.removeWhere((prod) => prod.id == id);
    notifyListeners();
    await _saveToLocalStorage();
  }
}
